
      <footer class="page-footer">
          
            <div class="grey-text text-lighten-4 container">
            © 2016 Copyright
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
        </footer>
 