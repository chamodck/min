<?php
	echo "connected";
?>